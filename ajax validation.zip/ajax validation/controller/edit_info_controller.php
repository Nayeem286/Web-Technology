<?php
require_once('../model/user-info-model.php');

function sanitize($data){
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

$response = ['errors' => []];
$id = $_COOKIE['id'];
$row= userInfo($id);

$fullname = sanitize($_POST['fullname']);
$email = sanitize($_POST['email']);
$phone = sanitize($_POST['phone']);
$username = sanitize($_POST['username']);

if(empty($fullname)){
    $response['errors']['fullname'] = 'Fullname can not be empty.';
} elseif (!preg_match("/^[a-zA-Z-' ]*$/", $fullname)) {
    $response['errors']['fullname'] = 'Fullname is not valid.';
}

if(empty($phone)){
    $response['errors']['phone'] = 'Phone number can not be empty.';
} elseif (!is_numeric($phone) || strlen($phone) != 11 || $phone[0] != '0' || $phone[1] != '1') {
    $response['errors']['phone'] = 'Phone number is not valid.';
}

if(empty($email)){
    $response['errors']['email'] = 'Email can not be empty.';
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $response['errors']['email'] = 'Email is not valid.';
} elseif ($email != $row['Email'] && !uniqueEmail($email)) {
    $response['errors']['email'] = 'Email already exists.';
}

if(empty($username)){
    $response['errors']['username'] = 'Username can not be empty.';
} elseif (!preg_match("/^[a-zA-Z-']*$/", $username)) {
    $response['errors']['username'] = 'Username is not valid.';
}

if (empty($response['errors'])) {
    if (updateUserInfo($id, $fullname, $email, $phone, $username) === true) {
        $response['success'] = true;
    } else {
        $response['errors']['general'] = 'Update failed. Please try again.';
    }
}

echo json_encode($response);
?>
