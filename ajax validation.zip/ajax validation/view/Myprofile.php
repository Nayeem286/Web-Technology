


<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="css/style.css"/>
    <title>View Profile</title>
</head>
<body>
<br>&nbsp;&nbsp;&nbsp;<a href="user-home.php"></a><br><br><br><br><br>
    <table width="21%" border="0" cellspacing="0" cellpadding="25" align="center">
        
            <tr>
            <td>
            <fieldset>
                Fullname  : <?php echo htmlspecialchars($row['Fullname'] ?? ''); ?> <br><br>
                Username  : <?php echo htmlspecialchars($row['Username'] ?? ''); ?> <br><br>
                Phone     : <?php echo htmlspecialchars($row['Phone'] ?? ''); ?> <br><br>
                Email     : <?php echo htmlspecialchars($row['Email'] ?? ''); ?> <br>
                </fieldset
            </td>

        </tr>
       
    </table>

    <br><br>
</body>
</html>