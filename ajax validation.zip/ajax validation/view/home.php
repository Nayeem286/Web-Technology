<?php

    session_start();
    if(!isset($_SESSION['login']))
    header('location:sign-in.php?err=unauthorized');
    require_once('../model/user-info-model.php');

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="user-home-styles.css"/>
    <script src="js/user-home.js"></script>
    <title>My Home</title>
    <style>
        h1{
            text-align: center;
            color: purple;}
    </style>
</head>
<body>
<h1>Welcome to the homepage.</h1>
    <table border=0 cellspacing=50 cellpading=5 width=50% align="center">
        <tr>
            <td>
            <table border=1 cellspacing=0 cellpading=5 width=60% align="center">
                <tr>
                    <td align="left">
                        <ul>
                            <li><a href="view-profile.php">My Profile</a></li>
                            <li><a href="edit-profile-info.php">Edit Profile</a></li>
                            <li><a href="change-account-password.php">Change Password</a></li>
                            <li><a href="../controller/logout-controller.php">Logout</a></li>
                        </ul>
                    </td>
                </tr>
            </table>
            </td>
        </tr>
    </table>
    
</body>
</html>