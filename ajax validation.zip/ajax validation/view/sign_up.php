<?php
$fullnameMsg = $emailMsg = $phoneMsg = $usernameMsg = $passwordMsg = $cpasswordMsg = $genderMsg = '';

if (isset($_GET['err'])) {
  $err_msg = $_GET['err'];
  
  switch ($err_msg) {
    case 'fullnameEmpty': {
        $fullnameMsg = "Fullname can not be empty.";
        break;
      }
    case 'phoneEmpty': {
        $phoneMsg = "Phone number can not be empty.";
        break;
      }
    case 'emailEmpty': {
        $emailMsg = "Email can not be empty.";
        break;
      }
    case 'usernameEmpty': {
        $usernameMsg = "Username can not be empty.";
        break;
      }
    case 'passwordEmpty': {
        $passwordMsg = "Password can not be empty.";
        break;
      }
    case 'cpasswordEmpty': {
        $cpasswordMsg = "Confirm password can not be empty.";
        break;
      }
    case 'fullnameInvalid': {
        $fullnameMsg = "Fullname is not valid.";
        break;
      }
    case 'phoneInvalid': {
        $phoneMsg = "Phone number is not valid.";
        break;
      }
    case 'emailInvalid': {
        $emailMsg = "Email is not valid.";
        break;
      }
    case 'emailExists': {
        $emailMsg = "Email already exists.";
        break;
      }
    case 'usernameInvalid': {
        $usernameMsg = "Username is not valid.";
        break;
      }
    case 'passwordInvalid': {
        $passwordMsg = "Password is not valid.";
        break;
      }
    case 'passwordMismatch': {
        $cpasswordMsg = "Passwords do not match.";
        break;
      }
    case 'genderEmpty': {
        $genderMsg = "Please select a gender.";
        break;
      }
  }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="sign-up-styles.css"/>
    <script src="js/sign-up.js"></script>
    <title>Sign Up</title>
    <style>
        h1{
            text-align: center;
            color: blue;}
        legend {
            font-size: 25px; 
            font-weight: bold;
          }
    </style>
</head>
<body>
<br>&nbsp;&nbsp;&nbsp;<a href="sign-in.php"></a><br><br><br>
<h1>American International University-Bangladesh</h1>
    <table width="35%" border="0" cellspacing="0" cellpadding="25" align="center">
        <tr>
            <td>
                <form method="post" action="../controller/sign-up-controller.php" onsubmit="return isValid(this);">
                <fieldset>
                <legend><b>Registration</b></legend><br>
                <div><span>Fullname</span></div>
                    <input type="text" name="fullname" size="43px" placeholder="Please enter your full name">
                    <?php if (strlen($fullnameMsg) > 0) { ?>
                        <br><br>
                        <font color="red"><?= $fullnameMsg ?></font>
                    <?php } ?>
                    <br><font color="red" id="fullnameError"></font><br>
                    
                    <div><span>Phone</span></div>
                    <input type="text" name="phone" size="43px" placeholder="Please enter your phone number">
                    <?php if (strlen($phoneMsg) > 0) { ?>
                        <br><br>
                        <font color="red"><?= $phoneMsg ?></font>
                    <?php } ?>
                    <br><font color="red" id="phoneError"></font><br>
                   
                    <div><span>Email</span></div>
                    <input type="email" name="email" size="43px" placeholder="Please enter your email">
                    <?php if (strlen($emailMsg) > 0) { ?>
                        <br><br>
                        <font color="red"><?= $emailMsg ?></font>
                    <?php } ?>
                    <br><font color="red" id="emailError"></font><br>
                    
                    <div><span>Username</span></div>
                    <input type="text" name="username" size="43px" placeholder="Please enter your username">
                    <?php if (strlen($usernameMsg) > 0) { ?>
                        <br><br>
                        <font color="red"><?= $usernameMsg ?></font>
                    <?php } ?>
                    <br><font color="red" id="usernameError"></font><br>

                    <div><span>Gender</span></div>
                    <input type="radio" name="gender" value="male"> Male
                    <input type="radio" name="gender" value="female"> Female
                    <input type="radio" name="gender" value="other"> Other
                    <?php if (strlen($genderMsg) > 0) { ?>
                        <br><br>
                        <font color="red"><?= $genderMsg ?></font>
                    <?php } ?>
                    <br><font color="red" id="genderError"></font><br>
                    
                    <div><span>Password</span></div>
                    <input type="password" name="password" size="43px" placeholder="Please enter a password">
                    <?php if (strlen($passwordMsg) > 0) { ?>
                        <br><br>
                        <font color="red"><?= $passwordMsg ?></font>
                    <?php } ?>
                    <br><font color="red" id="passwordError"></font><br>

                    <div><span>Confirm Password</span></div>
                    <input type="password" name="cpassword" size="43px" placeholder="Please re-enter your password">
                    <?php if (strlen($cpasswordMsg) > 0) { ?>
                        <br><br>
                        <font color="red"><?= $cpasswordMsg ?></font>
                    <?php } ?>
                    <br><font color="red" id="confirmPasswordError"></font><br>
                    <a href=button><button>Sign Up</button></a>
                    <input type="reset" value="Reset">
                </form>
            </td>
        </tr>
    </table>
</body>
</html>