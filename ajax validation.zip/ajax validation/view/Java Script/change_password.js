function isValid(form) {

    let prevpassword = form.prevpassword.value;
    let password = form.password.value;
    let cpassword = form.cpassword.value;
    
    let flag = true;

    document.getElementById("prevpasswordError").innerHTML = "";
    document.getElementById("passwordError").innerHTML = "";
    document.getElementById("cpasswordError").innerHTML = "";


    if (prevpassword === "") {
        document.getElementById("prevpasswordError").innerHTML = "Incorrect password.<br>";
        flag = false;
    }

    if (password === "") {
        document.getElementById("passwordError").innerHTML = "Please enter a new password.<br>";
        flag = false;
    }

    if (cpassword === "") {
        document.getElementById("cpasswordError").innerHTML = "Please re enter your password.<br>";
        flag = false;
    }

    return flag;

}

function checkPassword(){
    let prevpassword = document.getElementById('prevpassword').value;
    if(prevpassword.length == 0) {
        document.getElementById('prevpasswordError').innerHTML = "";
        return;
    }
    
    let xhttp = new XMLHttpRequest();
    xhttp.open('POST', '../controller/password-checker.php', true);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.send('password='+prevpassword);

    xhttp.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200){
            if(this.responseText == 'false'){
                document.getElementById('prevpasswordError').innerHTML = "Previous password is incorrect<br/>";
            }
            else{
                document.getElementById('prevpasswordError').innerHTML = "";
            }
        }
    }
}
