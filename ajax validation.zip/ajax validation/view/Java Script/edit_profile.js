document.getElementById('editProfileForm').addEventListener('submit', function (e) {
    e.preventDefault(); // Prevent default form submission

    // Get the form data
    const formData = new FormData(this);

    // Clear any previous error messages
    document.getElementById('fullnameError').innerHTML = '';
    document.getElementById('phoneError').innerHTML = '';
    document.getElementById('emailError').innerHTML = '';
    document.getElementById('usernameError').innerHTML = '';
    document.getElementById('successMessage').innerHTML = '';

    // Create an AJAX request
    const xhttp = new XMLHttpRequest();
    xhttp.open('POST', '../controller/edit-information-controller.php', true);
    xhttp.onreadystatechange = function () {
        if (this.readyState === 4 && this.status === 200) {
            let response = JSON.parse(this.responseText);

            // Handle errors
            if (response.errors) {
                if (response.errors.fullname) {
                    document.getElementById('fullnameError').innerHTML = response.errors.fullname;
                }
                if (response.errors.phone) {
                    document.getElementById('phoneError').innerHTML = response.errors.phone;
                }
                if (response.errors.email) {
                    document.getElementById('emailError').innerHTML = response.errors.email;
                }
                if (response.errors.username) {
                    document.getElementById('usernameError').innerHTML = response.errors.username;
                }
                if (response.errors.general) {
                    document.getElementById('generalError').innerHTML = response.errors.general;
                }
            }

            // Handle success
            if (response.success) {
                document.getElementById('successMessage').innerHTML = 'Profile updated successfully!';
            }
        }
    };

    // Send the form data
    xhttp.send(formData);
});
