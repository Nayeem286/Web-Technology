<!DOCTYPE html>
<html lang="en">

<head>
    <title>LOG IN</title>
    <script src="../asset/js/loginCheck.js"></script>
  
    <link rel="stylesheet"  href="../asset/css/login.css">
    
</head>

<body>

    <div class="center">
        <form method="post" action="../controller/loginCheck.php" onsubmit="return logIn();">
            <table border="0" cellspacing="0" cellpadding="0">
                <tr>
                    <td>
                        <fieldset style="width: 330px; padding: 20px;">
                        <h2 style="color: blue;">Signin</h2><br>

                            <div id="wrongPass"></div>
                            <style>
                            input[type="submit"] {width: 150px;height: 40px;font-size: 16px; }
                            input[type="submit"]:hover {color: yellow;}
                            </style>
                           
                            Username:  <input type="text" name="userName" id="userName" value="" /> <div id="username"></div><br><br>
                            Password: <input type="password" name="password" id="password" value="" /> <div id ="Password"></div> <br><br>

                            <input type="submit" name="submit" value="Submit" />
                            <br>
                            <br><a href="../controller/signup.php"> Signup</a><br>
                               <div class="left-align">
                                <h5>
                            <a href="forgetPass.php">Forget Password?</a>
                            </h5>
                            </div>
                        </fieldset>
                    </td>
                </tr>
            </table>
        </form>
    </div>

</body>

</html>
