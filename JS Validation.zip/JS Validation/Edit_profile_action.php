<?php 

    require_once('Model.php');

    function sanitize($data){

        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);

        return $data;

    }

    $id = $_COOKIE['id'];
    $row=  userInfo($id);

    $fullname = sanitize($_POST['fullname']);
    $email = sanitize($_POST['email']);
    $phone = sanitize($_POST['phone']);
    $username = sanitize($_POST['username']);

    if(empty($fullname)){
        header('location:g:\xampp\htdocs\JS Validation\Edit_profile.php?err=fullnameEmpty'); 
        exit();
    }
    if(empty($phone)){
        header('location:g:\xampp\htdocs\JS Validation\Edit_profile.php?err=phoneEmpty'); 
        exit();
    }
    if(empty($email)){
        header('location:g:\xampp\htdocs\JS Validation\Edit_profile.php?err=emailEmpty'); 
        exit();
    }
    if(empty($username)){
        header('location:g:\xampp\htdocs\JS Validation\Edit_profile.php?err=usernameEmpty'); 
        exit();
    }

    $namepart = explode(' ', $fullname);
    if(count($namepart) < 2) {
        header('location:g:\xampp\htdocs\JS Validation\Edit_profile.php?err=fullnameInvalid'); 
        exit();
    }
    if(!preg_match("/^[a-zA-Z-' ]*$/",$fullname)) {
        header('location:g:\xampp\htdocs\JS Validation\Edit_profile.php?err=fullnameInvalid'); 
        exit();
    }

    if($phone[0] == "0" && $phone[1] == "1") {}
    else{
        header('location:g:\xampp\htdocs\JS Validation\Edit_profile.php?err=phoneInvalid'); 
        exit();
    }
    if(is_numeric($phone)){
        if(strlen($phone)==11){}
        else {
            header('location:g:\xampp\htdocs\JS Validation\Edit_profile.php?err=phoneInvalid'); 
            exit();
        }
    }
    else {
        header('location:g:\xampp\htdocs\JS Validation\Edit_profile.php?err=phoneInvalid'); 
        exit();
    }
    

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)){
        header('location:g:\xampp\htdocs\JS Validation\Edit_profile.php?err=emailInvalid'); 
        exit();
    }
    if($email != $row['Email'] && uniqueEmail($email)==false){
        header('location:g:\xampp\htdocs\JS Validation\Edit_profile.php?err=emailExists'); 
        exit();
    }
    if (!preg_match("/^[a-zA-Z-']*$/", $username)){
        header('location:g:\xampp\htdocs\JS Validation\Edit_profile.php?err=usernameInvalid'); 
        exit();
    }
    
    
    if(updateUserInfo($id, $fullname, $email, $phone, $username) === true){
        header('location:g:\xampp\htdocs\JS Validation\Edit_profile.php?success=changed'); 
        exit();
    }


?>