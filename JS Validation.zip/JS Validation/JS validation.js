function isValidSignUp(form) {
    let fullname = form.fullname.value;
    let phone = form.phone.value;
    let email = form.email.value;
    let username = form.username.value;
    let password = form.password.value;
    let cpassword = form.cpassword.value; 
    let genderElements = form.gender; 
    let genderSelected = false;
    let flag = true;

    document.getElementById("fullnameError").innerHTML = "";
    document.getElementById("phoneError").innerHTML = "";
    document.getElementById("emailError").innerHTML = "";
    document.getElementById("usernameError").innerHTML = "";
    document.getElementById("passwordError").innerHTML = "";
    document.getElementById("confirmPasswordError").innerHTML = "";
    document.getElementById("genderError").innerHTML = "";

    if (fullname === "") {
        document.getElementById("fullnameError").innerHTML = "Please enter your full name.<br>";
        flag = false;
    }

    if (phone === "") {
        document.getElementById("phoneError").innerHTML = "Please enter your phone number.<br>";
        flag = false;
    }


    if (email === "") {
        document.getElementById("emailError").innerHTML = "Please enter your email address.<br>";
        flag = false;
    }

    if (username === "") {
        document.getElementById("usernameError").innerHTML = "Please enter a username.<br>";
        flag = false;
    }
    if (password === "") {
        document.getElementById("passwordError").innerHTML = "Please enter a password.<br>";
        flag = false;
    } else if (password.length < 8) {
        document.getElementById("passwordError").innerHTML = "Password must be at least 8 characters long.<br>";
        flag = false;
    }

    if (cpassword === "") {
        document.getElementById("confirmPasswordError").innerHTML = "Please confirm your password.<br>";
        flag = false;
    } else if (password !== cpassword) {
        document.getElementById("confirmPasswordError").innerHTML = "Passwords do not match.<br>";
        flag = false;
    }

    for (let i = 0; i < genderElements.length; i++) {
        if (genderElements[i].checked) {
            genderSelected = true;
            break;
        }
    }
    if (!genderSelected) {
        document.getElementById("genderError").innerHTML = "Please select your gender.<br>";
        flag = false;
    }

    return flag;
}
