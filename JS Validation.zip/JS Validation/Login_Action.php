<?php
session_start();
require_once('Model.php');

if(isset($_POST['submit'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    if(strlen(trim($email)) == 0 || strlen(trim($password)) == 0){
        header('location:Login.php?err=empty');
        exit();
    }

    $status = login($email, $password);

    if($status != false){
        $_SESSION["login"] = true;
        setcookie("id", $status['userID'], time() + 99999999999, "/");
        header('location:g:\xampp\htdocs\JS Validation\My_home.php');
        exit();
    } else {
        header('location:Login.php?err=mismatch');
        exit();
    }
}
?>
