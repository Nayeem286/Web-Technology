<?php 

require_once('Model.php');

function sanitize($data){
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

$fullname = sanitize($_POST['fullname']);
$email = sanitize($_POST['email']);
$username = sanitize($_POST['username']);
$password = sanitize($_POST['password']);
$cpassword = sanitize($_POST['cpassword']);
$phone = sanitize($_POST['phone']);
$gender = sanitize($_POST['gender']);
$role = "User";

if (empty($fullname)) {
    header('Location: Registration.php?err=fullnameEmpty'); 
    exit();
}
if (empty($email)) {
    header('Location: Registration.php?err=emailEmpty'); 
    exit();
}
if (empty($username)) {
    header('Location: Registration.php?err=usernameEmpty'); 
    exit();
}
if (empty($password)) {
    header('Location: Registration.php?err=passwordEmpty'); 
    exit();
}
if (empty($cpassword)) {
    header('Location: Registration.php?err=cpasswordEmpty'); 
    exit();
}
if (empty($phone)) {
    header('Location: Registration.php?err=phoneEmpty'); 
    exit();
}
if (empty($gender)) {
    header('Location: Registration.php?err=genderEmpty'); 
    exit();
}

// Fullname validation
$namepart = explode(' ', $fullname);
if (count($namepart) < 2 || !preg_match("/^[a-zA-Z-' ]*$/", $fullname)) {
    header('Location: Registration.php?err=fullnameInvalid'); 
    exit();
}

// Phone validation
if (!preg_match("/^01[0-9]{9}$/", $phone)) {  // Adjust the regex pattern as needed
    header('Location: Registration.php?err=phoneInvalid'); 
    exit();
}

// Email validation
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header('Location: Registration.php?err=emailInvalid'); 
    exit();
}
if (!uniqueEmail($email)) {
    header('Location: Registration.php?err=emailExists'); 
    exit();
}

// Username validation
if (!preg_match("/^[a-zA-Z0-9_]*$/", $username)) {  // Adjust regex for valid username characters
    header('Location: Registration.php?err=usernameInvalid'); 
    exit();
}

// Password validation
if (strlen($password) < 5) {
    header('Location: Registration.php?err=passwordInvalid'); 
    exit();
}
if ($password != $cpassword) {
    header('Location: Registration.php?err=passwordMismatch'); 
    exit();
}

// Call the signup function
$status = signup($fullname, $email, $username, $password, $phone, $gender, $role);
if ($status) {
    header('Location: sign-in.php?success=created');
    exit();
}

?>
