<?php

    session_start();
    if(!isset($_SESSION['login'])) header('location:g:\xampp\htdocs\JS Validation\Login.php?err=unauthorized');
    require_once('g:\xampp\htdocs\JS Validation\Model.php'); 
    $id = $_COOKIE['id'];
    $row = userInfo($id);
 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    
    <link rel="stylesheet" href="style.css"/>
    <title>View Profile</title>
</head>
<body>
<br>&nbsp;&nbsp;&nbsp;<a href="g:\xampp\htdocs\JS Validation\My_home.php">< Back</a><br><br><br><br><br>
    <table width="21%" border="0" cellspacing="0" cellpadding="25" align="center">
        <tr>
            <?php

                echo "<td>
                    Fullname  : {$row['Fullname']} <br><br>
                    Username  : {$row['Username']} <br><br>
                    Phone     : {$row['Phone']} <br><br>
                    Email     : {$row['Email']} <br>
                </td>";

            ?>
        </tr>
    </table>
    <br><br>
</body>
</html>