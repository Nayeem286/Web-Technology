<?php
    session_start();
    if(!isset($_SESSION['login']))
    header('location:g:\xampp\htdocs\JS Validation\Login.php?err=unauthorized');
    require_once('Model.php');    
  
    $id = $_COOKIE['id'];
    $row = userInfo($id);

    $fullname = $email = $phone =  $username = '';

    if (isset($_GET['err'])) {

    $err_msg = $_GET['err'];
    
    switch ($err_msg) {
        case 'fullnameEmpty': {
            $fullname = "Fullname can not be empty.";
            break;
        }
        case 'phoneEmpty': {
            $phone = "Phone number can not be empty.";
            break;
        }
        case 'emailEmpty': {
            $email = "Email can not be empty.";
            break;
        }
        case 'usernameEmpty': {
            $username = "Username can not be empty.";
            break;
        }
        case 'fullnameInvalid': {
            $fullname = "Fullname is not valid.";
            break;
        }
        case 'phoneInvalid': {
            $phone = "Phone number is not valid.";
            break;
        }
        case 'emailInvalid': {
            $email = "Email is not valid.";
            break;
        }
        case 'emailExists': {
            $email = "Email already exists.";
            break;
        }
        case 'usernameInvalid': {
            $username = "Username is not valid.";
            break;
        }
    }
    }

$success_msg = '';

if (isset($_GET['success'])) {

  $s_msg = $_GET['success'];

  switch ($s_msg) {
    case 'changed': {
        $success_msg = "Profile successfully updated.";
        break;
      }
  }
}

?>  
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css"/>
    <title>Edit Profile</title>
</head>
<body>
<br>&nbsp;&nbsp;&nbsp;<a href="g:\xampp\htdocs\JS Validation\My_home.php">< Back</a><br><br><br><br>
    <table width="21%" border="0" cellspacing="0" cellpadding="25" align="center">
        <tr>
            <td>
                <form method="post" action="g:\xampp\htdocs\JS Validation\Edit_profile_action.php">
                    <fieldset>
                    <div><span>Fullname</span></div>
                    <input type="text" name="fullname" size="43px" value= "<?php echo "{$row['Fullname']}"; ?>">
                    <?php if (strlen($fullname) > 0) { ?>
                        <br><br>
                        <font color="red"><?= $fullname ?></font>
                    <?php } ?>
                    <br><br>
                    <div><span>Phone</span></div>
                    <input type="text" name="phone" size="43px" value= "<?php echo "{$row['Phone']}"; ?>">
                    <?php if (strlen($phone) > 0) { ?>
                        <br><br>
                        <font color="red"><?= $phone ?></font>
                    <?php } ?>
                    <br><br>
                    <div><span>Email</span></div>
                    <input type="email" name="email" size="43px" value= "<?php echo "{$row['Email']}"; ?>" onkeyup="checkEmailValidity(this.value)">
                    <?php if (strlen($email) > 0) { ?>
                        <br><br>
                        <font color="red"><?= $email ?></font>
                    <?php } ?>
                    <br><br>
                    <div><span>Username</span></div>
                    <input type="text" name="username" size="43px" value= "<?php echo "{$row['Username']}"; ?>">
                    <?php if (strlen($username) > 0) { ?>
                        <br><br>
                        <font color="red"><?= $username ?></font>
                    <?php } ?>
                    <br><br>
                    <?php if (strlen($success_msg) > 0) { ?>
                        <font color="green" align="center"><?= $success_msg ?></font>
                        <br><br>
                    <?php } ?>
                    <button>Update Profile</button>
                    
                </form>
            </td>
        </tr>
    </table>
    
</body>
</html>