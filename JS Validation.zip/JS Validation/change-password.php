<?php
require_once('g:\xampp\htdocs\JS Validation\Model.php');
session_start();
if(!isset($_SESSION['mail'])) 
$row = getUserByMail($_SESSION['mail']);
$error_msg = '';

if (isset($_GET['err'])) {

  $err_msg = $_GET['err'];
  
  switch ($err_msg) {
    
    case 'invalid': {
        $error_msg = "Password is invalid.";
        break;
      }
    case 'mismatch': {
        $error_msg = "Passwords do not match.";
        break;
      }
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css"/>
    <title>Change Password</title>
</head>
<body>
    <table width="21%" border="1" cellspacing="0" cellpadding="25" align="center">
        <tr>
            <td>
                <form method="post" action="g:\xampp\htdocs\JS Validation\change_password_action.php" novalidate autocomplete="off">
                    <div><span>New Password</span></div>
                    <input type="password" name="password" size="43px">
                    <br><br>
                    
                    <div><span>Confirm New Password</span></div>
                    <input type="password" name="cpassword" size="43px">
                    <?php if (strlen($error_msg) > 0) { ?>
                        <br><br>
                        <font color="red" align="center"><?= $error_msg ?></font>
                    <?php } ?>
                    <br><br>
                    <button name="submit">Change Password</button>
                </form>
            </td>
        </tr>
    </table>
</body>
</html>