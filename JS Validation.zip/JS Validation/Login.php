<?php

$error_msg = '';

if (isset($_GET['err'])) {

  $err_msg = $_GET['err'];
  
  switch ($err_msg) {
    case 'mismatch': {
        $error_msg = "Wrong username or password.";
        break;
      }
    case 'empty': {
        $error_msg = "Field can not be empty.";
        break;
      }
    case 'unauthorized': {
        $error_msg = "You have to login first.";
        break;
      }
  }
}

$success_msg = '';

if (isset($_GET['success'])) {

  $s_msg = $_GET['success'];

  switch ($s_msg) {
    case 'created': {
        $success_msg = "Your Account create successfully..";
        break;
      }
    case 'changed': {
        $success_msg = "Password change successfully.";
        break;
      }
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    
    <link rel="stylesheet" href="style.css"/>
    <script src="JS validation.js"></script>
    <title>Log In</title>
</head>
<body>
    <br>
    <center><h2>My Profile</h2> </center>
  
    <br><br><br>
    <table width="21%" border="0" cellspacing="0" cellpadding="25" align="center">
        <tr>
            <td>
                <form method="post" action="Login_Action.php" novalidate onsubmit= "return isValidSignIn(this);">
                <fieldset> 
                  <legend>Login</legend>
                  <br>
                  <div><span>Email</span></div>
                    <input type="email" name="email" id="email" size="43px">
                    <br><font color="red" id="emailError"></font><br>

                    <div><span>Password</span></div>
                    <input type="password" name="password" id="password" size="43px">
                    <br><font color="red" id="passwordError"></font><br>
                    <div align="right">

                        <a href="forgot-password.php">Forgot Password?</a>
                        <h1><h3 align=right></h3><a href="Registration.php"></a></h1>
                    </div>
                    <?php if (strlen($error_msg) > 0) { ?>
                        <br>
                        <font color="red" align="center"><?= $error_msg ?></font>
                        <br><br>
                    <?php } ?>
                    <?php if (strlen($success_msg) > 0) { ?>
                        <br>
                        <font color="green" align="center"><?= $success_msg ?></font>
                        <br><br>
                    <?php } ?>
                    <br>
                    <center><button class="login-button" name="submit">Login</button></center>
                    </form>
                    </fieldset> 
            </td>
        </tr>
    </table>

</body>
</html>