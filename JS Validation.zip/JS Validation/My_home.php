<?php

    session_start();
    if(!isset($_SESSION['login']))
    header('location:g:\xampp\htdocs\JS Validation\Login.php?err=unauthorized');

    require_once('Model.php');
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css"/>
    <title>Home</title>
</head>
<body>
    <div class="center-container">
        <h1>Hi, Welcome to my profile</h1>
        <div class="container">
            <table class="menu-table">
                <tr>
                    <td>
                        <table class="menu-content">
                            <tr>
                                <td>
                                    <ul class="menu-list">
                                        <li><a href="view_profile.php">My Profile</a></li>
                                        <li><a href="g:\xampp\htdocs\JS Validation\Edit_profile.php">Edit Profile</a></li>
                                        <li><a href="change_password.php">Change Password</a></li>
                                        <li><a href="../controller/logout-controller.php">Logout</a></li>
                                    </ul>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</body>
</html>
