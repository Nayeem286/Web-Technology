<?php
$fullname = $email = $username = $password = $change_password = $phone = $gender = '';

if (isset($_GET['err'])) {
    $err_msg = $_GET['err'];

    switch ($err_msg) {
        case 'fullnameEmpty':
            $fullname = "Fullname must be filled in.";
            break;
        case 'emailEmpty':
            $email = "Email must be filled in.";
            break;
        case 'phoneEmpty':
            $phone = "Phone must be filled in.";
            break;
        case 'usernameEmpty':
            $username = "Username must be filled in.";
            break;
        case 'passwordEmpty':
            $password = "Password must be filled in.";
            break;
        case 'change_password':
            $change_password = "Confirm password must be filled in.";
            break;
        case 'fullnameInvalid':
            $fullname = "Fullname is not valid.";
            break;
        case 'phoneInvalid':
            $phone = "Phone number is not valid.";
            break;
        case 'emailInvalid':
            $email = "Email is not valid.";
            break;
        case 'emailExists':
            $email = "Email already exists.";
            break;
        case 'usernameInvalid':
            $username = "Username is not valid.";
            break;
        case 'passwordInvalid':
            $password = "Password is not valid.";
            break;
        case 'passwordMismatch':
            $change_password = "Passwords do not match.";
            break;
        case 'genderEmpty':
            $gender = "Please select your gender.";
            break;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css"/>
    <script src="JS validation.js"></script>
    <title>Sign Up</title>
</head>
<body>
    <br>&nbsp;&nbsp;&nbsp;<a href="Login.php"></a><br><br><br>
    <table width="21%" border="0" cellspacing="0" cellpadding="25" align="center">
        <tr>
            <td>
                <form method="post" action="Registration_Action.php" onsubmit="return isValidSignUp(this);">
                    <fieldset>
                        <legend><b style="font-size: 1.2em;">REGISTRATION</b></legend>
                        <br>
                        <div><span>Fullname</span></div>
                        <input type="text" name="fullname" size="43px" placeholder="Please enter your full name">
                        <?php if (strlen($fullname) > 0) { ?>
                            <br><br>
                            <font color="red"><?= $fullname ?></font>
                        <?php } ?>
                        <br><font color="red" id="fullnameError"></font><br>

                        <div><span>Phone</span></div>
                        <input type="text" name="phone" size="43px" placeholder="Please enter your phone number">
                        <?php if (strlen($phone) > 0) { ?>
                            <br><br>
                            <font color="red"><?= $phone ?></font>
                        <?php } ?>
                        <br><font color="red" id="phoneError"></font><br>

                        <div><span>Email</span></div>
                        <input type="email" name="email" size="43px" placeholder="Please enter your email">
                        <?php if (strlen($email) > 0) { ?>
                            <br><br>
                            <font color="red"><?= $email ?></font>
                        <?php } ?>
                        <br><font color="red" id="emailError"></font><br>
                        
                        <div><span>Username</span></div>
                        <input type="text" name="username" size="43px" placeholder="Please enter your username">
                        <?php if (strlen($username) > 0) { ?>
                            <br><br>
                            <font color="red"><?= $username ?></font>
                        <?php } ?>
                        <br><font color="red" id="usernameError"></font><br>

                        <div><span>Password</span></div>
                        <input type="password" name="password" size="43px" placeholder="Please enter a password">
                        <?php if (strlen($password) > 0) { ?>
                            <br><br>
                            <font color="red"><?= $password ?></font>
                        <?php } ?>
                        <br><font color="red" id="passwordError"></font><br>

                        <div><span>Confirm Password</span></div>
                        <input type="password" name="cpassword" size="43px" placeholder="Please re-enter your password">
                        <?php if (strlen($change_password) > 0) { ?>
                            <br><br>
                            <font color="red"><?= $change_password ?></font>
                        <?php } ?>
                        <br><font color="red" id="confirmPasswordError"></font><br>

                        <div><span>Gender</span></div>
                        <input type="radio" name="gender" value="male"> Male
                        <input type="radio" name="gender" value="female"> Female
                        <input type="radio" name="gender" value="other"> Other
                        <?php if (strlen($gender) > 0) { ?>
                            <br><br>
                            <font color="red"><?= $gender ?></font>
                        <?php } ?>
                        <br><font color="red" id="genderError"></font><br>

                        <button type="submit">Sign Up</button>
                    </fieldset>
                </form>
            </td>
        </tr>
    </table>
</body>
</html>
