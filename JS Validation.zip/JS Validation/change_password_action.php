<?php

require_once('Model.php');

session_start();


    $mail = $_SESSION['mail'];
    $row = getUserByMail($mail); 
    $id = $row['UserID'];
    $answer = $_POST['answer'];
    
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];

    if(empty($_POST['answer'])){
        header('location:g:\xampp\htdocs\JS Validation\change-password.php?err=empty');
        exit();
    }

    if($answer != $canswer){
        header('location:g:\xampp\htdocs\JS Validation\change-password.php?err=answerError');
        exit();
    }

    if(strlen($password)<8){
        header('location:g:\xampp\htdocs\JS Validation\change-password.php?err=invalid');
        exit();
    }

    if($password!=$cpassword){
        header('location:g:\xampp\htdocs\JS Validation\change-password.php?err=mismatch');
        exit();
    }

    else{
        if(changePassword($id, $password) === true){
            header('location:g:\xampp\htdocs\JS Validation\Login.php?success=changed');
            exit();
        }
    }
    

?>