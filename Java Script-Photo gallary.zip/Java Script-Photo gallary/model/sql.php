<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = ""; 
$dbname = "aiub"; 

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL Queries
$sql = "
CREATE TABLE IF NOT EXISTS `userinfo` (
  `userID` int(11) NOT NULL AUTO_INCREMENT,
  `Fullname` varchar(500) NOT NULL,
  `Phone` varchar(15) NOT NULL,   -- Adjusted length for phone number
  `Email` varchar(100) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `Password` varchar(255) NOT NULL,  -- Consider this length for hashed passwords
  `Role` varchar(50) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  PRIMARY KEY (`userID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
";

// Execute the CREATE TABLE query
if ($conn->query($sql) === TRUE) {
    echo "Table created successfully<br>";
} else {
    echo "Error creating table: " . $conn->error;
}

// Insert initial data
$insertSql = "
INSERT INTO `userinfo` (`Fullname`, `Phone`, `Email`, `Username`, `Password`, `Role`, `Gender`) VALUES
('nusrat jahan', '01993865461', 'nusrat@gmail.com', 'nus', '12344321', 'User', 'Female');
";

// Execute the INSERT query
if ($conn->query($insertSql) === TRUE) {
    echo "Data inserted successfully";
} else {
    echo "Error inserting data: " . $conn->error;
}

// Close connection
$conn->close();
?>
