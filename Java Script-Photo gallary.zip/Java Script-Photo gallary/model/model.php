<?php

require_once('database.php');

$row;

function login($email, $password){
    global $row;

    $con = dbConnection();
    $sql = $con->prepare("SELECT * FROM UserInfo WHERE email = ? AND password = ?");
    $sql->bind_param("ss", $email, $password);
    $sql->execute();
    $result = $sql->get_result();
    $count = mysqli_num_rows($result);

    if($count == 1) {
        $row = mysqli_fetch_assoc($result);
        $_SESSION['id'] = $row['UserID'];  // Set the user ID in the session
        $_SESSION['login'] = true;  // Set a login flag
        return $row;
    } else {
        return false;
    }
}

function signup($fullname, $phone, $email, $username, $password, $gender, $role) {
    $con = dbConnection();
    $sql = $con->prepare("INSERT INTO UserInfo (fullname, phone, email, username, password, gender, role) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $sql->bind_param("sssssss", $fullname, $phone, $email, $username, $password, $gender, $role);

    return $sql->execute();
}


function uniqueEmail($email) {
    $con = dbConnection();
    $sql = $con->prepare("SELECT email FROM UserInfo WHERE email = ?");
    $sql->bind_param("s", $email);
    $sql->execute();
    $result = $sql->get_result();
    $count = mysqli_num_rows($result);

    if($count > 0) {
        return false;
    } else {
        return true; 
    }
}

function getUserByMail($email) {
    $con = dbConnection();
    $sql = $con->prepare("SELECT * FROM UserInfo WHERE email = ?");
    $sql->bind_param("s", $email);
    $sql->execute();
         
    $result = $sql->get_result();
    $row = mysqli_fetch_assoc($result);
    return $row;
}

function changePassword($id, $newpass) {
    $con = dbConnection();
    $sql = $con->prepare("UPDATE UserInfo SET password = ? WHERE UserID = ?");
    $sql->bind_param("ss", $newpass, $id);

    if($sql->execute() === true) {
        return true;
    } else {
        return false; 
    }
}

function userInfo($id) {
    $con = dbConnection();
    $sql = $con->prepare("SELECT * FROM UserInfo WHERE UserID = ?");
    $sql->bind_param("s", $id);
    $sql->execute();
    $result = $sql->get_result();
    $row = $result->fetch_assoc();
    
    return $row;
}

function updateUserInfo($id, $fullname, $email, $phone, $username) {
    $con = dbConnection();
    $sql = $con->prepare("UPDATE UserInfo SET fullname = ?, username = ?, phone = ?, email = ? WHERE UserID = ?");
    $sql->bind_param("sssss", $fullname, $username, $phone, $email, $id);

    if($sql->execute() === true) {
        return true;
    } else {
        return false; 
    }
}

function isExistUser($email){
    $con = dbConnection();
    $sql = "SELECT * from UserInfo where Email='{$email}'";
    $result = mysqli_query($con, $sql);
    $count = mysqli_num_rows($result);
    if($count == 1){
        return true;
    }else{
        return false;
    }
}

function correctPassword($id, $password){
    $con = dbConnection();
    $sql = "SELECT * from UserInfo where UserID='{$id}' and Password ='{$password}'";
    $result = mysqli_query($con, $sql);
    $count = mysqli_num_rows($result);
    if($count == 1) return true; 
    else return false;
}



?>
