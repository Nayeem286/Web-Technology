<?php
    session_start();
    if(!isset($_SESSION['login'])) header('location:sign-in.php?err=unauthorized');
    require_once('../model/user-info-model.php');    
  
    $id = $_COOKIE['id'];
    $row = userInfo($id);

    $fullnameMsg = $emailMsg = $phoneMsg =  $usernameMsg = '';

    if (isset($_GET['err'])) {

    $err_msg = $_GET['err'];
    
    switch ($err_msg) {
        case 'fullnameEmpty': {
            $fullnameMsg = "Fullname can not be empty.";
            break;
        }
        case 'phoneEmpty': {
            $phoneMsg = "Phone number can not be empty.";
            break;
        }
        case 'emailEmpty': {
            $emailMsg = "Email can not be empty.";
            break;
        }
        case 'usernameEmpty': {
            $usernameMsg = "Username can not be empty.";
            break;
        }
        case 'fullnameInvalid': {
            $fullnameMsg = "Fullname is not valid.";
            break;
        }
        case 'phoneInvalid': {
            $phoneMsg = "Phone number is not valid.";
            break;
        }
        case 'emailInvalid': {
            $emailMsg = "Email is not valid.";
            break;
        }
        case 'emailExists': {
            $emailMsg = "Email already exists.";
            break;
        }
        case 'usernameInvalid': {
            $usernameMsg = "Username is not valid.";
            break;
        }
    }
    }

$success_msg = '';

if (isset($_GET['success'])) {

  $s_msg = $_GET['success'];

  switch ($s_msg) {
    case 'changed': {
        $success_msg = "Information successfully updated.";
        break;
      }
  }
}

?> 
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/edit-profile-info-styles.css"/>
    <script src="js/edit-profile-info.js"></script>
    <title>Edit Profile Info</title>
</head>
<body>
<br>&nbsp;&nbsp;&nbsp;<a href="user-home.php">< Back</a><br><br><br><br>
<table width="21%" border="0" cellspacing="0" cellpadding="25" align="center">
        <tr>
            <td>
                <form onsubmit="return updateProfile();">
                    <fieldset>
                    <div><span>Fullname</span></div>
                    <input type="text" name="fullname" size="43px" value="<?php echo "{$row['Fullname']}"; ?>">
                    <br><font color="red" id="fullnameError"></font><br>

                    <div><span>Phone</span></div>
                    <input type="text" name="phone" size="43px" value="<?php echo "{$row['Phone']}"; ?>">
                    <br><font color="red" id="phoneError"></font><br>

                    <div><span>Email</span></div>
                    <input type="text" name="email" size="43px" value="<?php echo "{$row['Email']}"; ?>">
                    <br><font color="red" id="emailError"></font><br>

                    <div><span>Username</span></div>
                    <input type="text" name="username" size="43px" value="<?php echo "{$row['Username']}"; ?>">
                    <br><font color="red" id="usernameError"></font><br>

                    <br><font color="green" id="successMessage"></font><br>

                    <button>Update Profile</button>
                </form>
                </fieldset>
            </td>
        </tr>
    </table>
</body>
</html>