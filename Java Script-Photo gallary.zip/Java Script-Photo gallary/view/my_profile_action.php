<?php
// gallery.php

session_start();
require_once 'database.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: sign-in.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$error = "";
$success = "";

// Define upload directory
$target_dir = __DIR__ . DIRECTORY_SEPARATOR . "uploads" . DIRECTORY_SEPARATOR;

// Create the upload directory if it doesn't exist
if (!file_exists($target_dir)) {
    mkdir($target_dir, 0777, true);
}

// Check if the directory is writable
if (!is_writable($target_dir)) {
    die("Error: Upload directory is not writable. Please check permissions.");
}

// Handle file upload
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES['photo'])) {
    $file_name = preg_replace('/[^a-zA-Z0-9\._-]/', '', basename($_FILES["photo"]["name"]));
    $target_file = $target_dir . uniqid() . "_" . $file_name; // Unique file name to avoid collisions
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    
    // Check if the file is a real image
    $check = getimagesize($_FILES["photo"]["tmp_name"]);
    if ($check !== false) {
        $uploadOk = 1;
    } else {
        $error = "File is not an image.";
        $uploadOk = 0;
    }

    // Check file size (up to 5MB)
    $max_file_size = 5 * 1024 * 1024; // 5MB in bytes
    if ($_FILES["photo"]["size"] > $max_file_size) {
        $error = "Sorry, your file is too large. Maximum file size is 5MB.";
        $uploadOk = 0;
    }

    // Allow certain file formats
    $allowed_formats = ["jpg", "jpeg", "png", "gif"];
    if (!in_array($imageFileType, $allowed_formats)) {
        $error = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }

    // Attempt to upload the file
    if ($uploadOk == 1) {
        if (move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file)) {
            $db_filename = "uploads/" . basename($target_file); // Relative path for the database
            $sql = "INSERT INTO photos (user_id, filename) VALUES (?, ?)";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "is", $user_id, $db_filename);
            
            if (mysqli_stmt_execute($stmt)) {
                $success = "The file " . basename($_FILES["photo"]["name"]) . " has been uploaded.";
                // Redirect to my_gallery.php after successful upload
                header("Location: my_gallery.php?success=" . urlencode($success));
                exit();
            } else {
                $error = "Sorry, there was an error uploading your file to the database.";
            }
        } else {
            $error = "Sorry, there was an error uploading your file to the server. Error: " . error_get_last()['message'];
        }
    }
}

// If there's an error, redirect back to my_gallery.php with the error message
if (!empty($error)) {
    header("Location: my_gallery.php?error=" . urlencode($error));
    exit();
}
?>