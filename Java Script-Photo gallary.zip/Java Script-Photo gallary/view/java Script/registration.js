function isValidSignUp(form) {

    let fullname = form.fullname.value;
    let phone = form.phone.value;
    let email = form.email.value;
    let username = form.username.value;
    let gender = form.gender.value; // Capture gender input
    let password = form.password.value;
    let cpassword = form.cpassword.value;
    let flag = true;

    // Clear previous error messages
    document.getElementById("fullnameError").innerHTML = "";
    document.getElementById("phoneError").innerHTML = "";
    document.getElementById("emailError").innerHTML = "";
    document.getElementById("usernameError").innerHTML = "";
    document.getElementById("passwordError").innerHTML = "";
    document.getElementById("confirmPasswordError").innerHTML = "";
    document.getElementById("genderError").innerHTML = "";  // Added for gender validation

    // Validate Fullname
    if (fullname === "") {
        document.getElementById("fullnameError").innerHTML = "Please enter your full name.<br>";
        flag = false;
    }

    // Validate Phone
    if (phone === "") {
        document.getElementById("phoneError").innerHTML = "Please enter your phone number.<br>";
        flag = false;
    }

    // Validate Email
    if (email === "") {
        document.getElementById("emailError").innerHTML = "Please enter your email address.<br>";
        flag = false;
    }

    // Validate Username
    if (username === "") {
        document.getElementById("usernameError").innerHTML = "Please enter a username.<br>";
        flag = false;
    }

    // Validate Gender (new validation for gender selection)
    if (!gender) {
        document.getElementById("genderError").innerHTML = "Please select your gender.<br>";
        flag = false;
    }

    // Validate Password
    if (password === "") {
        document.getElementById("passwordError").innerHTML = "Please enter a password.<br>";
        flag = false;
    } else if (password.length < 8) {
        document.getElementById("passwordError").innerHTML = "Password must be at least 8 characters long.<br>";
        flag = false;
    }

    // Validate Confirm Password
    if (cpassword === "") {
        document.getElementById("confirmPasswordError").innerHTML = "Please confirm your password.<br>";
        flag = false;
    }

    // Check if Password and Confirm Password match
    if (password !== cpassword) {
        document.getElementById("confirmPasswordError").innerHTML = "Passwords do not match.<br>";
        flag = false;
    }

    return flag;
}

function checkEmail(){
    let email = document.getElementById('email').value;
    if(email.length == 0) {
        document.getElementById('emailError').innerHTML = "";
        return;
    }
    
    let xhttp = new XMLHttpRequest();
    xhttp.open('POST', '../controller/checker.php', true);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.send('email='+email);

    xhttp.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200){
            if(this.responseText == 'false'){
                document.getElementById('emailError').innerHTML = "";
            }
            else{
                document.getElementById('emailError').innerHTML = "This email already exists in our database.<br/>";
            }
        }
    }
}
