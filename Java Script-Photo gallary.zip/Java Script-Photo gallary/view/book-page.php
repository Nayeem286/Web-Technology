<?php

    session_start();
    if(!isset($_SESSION['login'])) header('location:sign-in.php?err=unauthorized');

    require_once('../model/book-info-model.php');

    $bookInfo = getBookInfo($_GET['id'])

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Page</title>
</head>
<body>
<br>&nbsp;&nbsp;&nbsp;<a href="user-home.php">< Back</a>
    <table border="0" cellspacing="50" cellpading="50" width="100%" align="center">
        <tr>
            <td>
                <p align="right"><a href="../controller/add-to-wishlist-controller.php?id=<?php echo $bookInfo["BookID"] ?>">Add to Wishlist</a></p>
                <b>Book Title:</b> <?php echo $bookInfo["BookTitle"] ?> <br><br>
                <b>Author:</b> <?php echo $bookInfo["Author"] ?> <br><br><br>
                <?php echo $bookInfo["Content"] ?>
            </td>
        </tr>
    </table>
</body>
</html>