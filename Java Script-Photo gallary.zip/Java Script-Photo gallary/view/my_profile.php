<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Photo</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Upload Photo</h2>
        <form action="my_profile_action.php" method="post" enctype="multipart/form-data">
            <input type="file" name="photo" required>
            <br><br>
            <button type="submit">Upload Photo</button>
            <br><br>
        </form>
        <a href="my_gallery.php">Go to My Gallery</a>
        <br><br>
        <a href="logout.php">Logout</a>
    </div>
</body>
</html>