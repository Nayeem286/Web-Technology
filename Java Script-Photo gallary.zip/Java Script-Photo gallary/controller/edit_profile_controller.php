<?php 

require_once('../model/user-info-model.php');

// Function to sanitize input
function sanitize($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Initialize response array
$response = ['errors' => [], 'success' => false];

// Get the user ID from the cookie
$id = $_COOKIE['id'];
$row = userInfo($id);

// Sanitize and retrieve form data
$fullname = sanitize($_POST['fullname']);
$email = sanitize($_POST['email']);
$phone = sanitize($_POST['phone']);
$username = sanitize($_POST['username']);

// Validate form inputs

// Fullname validation
if (empty($fullname)) {
    $response['errors']['fullname'] = "Fullname cannot be empty.";
} else {
    $namepart = explode(' ', $fullname);
    if (count($namepart) < 2) {
        $response['errors']['fullname'] = "Fullname must contain at least two words.";
    }
    if (!preg_match("/^[a-zA-Z-' ]*$/", $fullname)) {
        $response['errors']['fullname'] = "Fullname contains invalid characters.";
    }
}

// Phone validation
if (empty($phone)) {
    $response['errors']['phone'] = "Phone number cannot be empty.";
} else {
    if ($phone[0] != "0" || $phone[1] != "1") {
        $response['errors']['phone'] = "Phone number must start with '01'.";
    } elseif (!is_numeric($phone) || strlen($phone) != 11) {
        $response['errors']['phone'] = "Phone number must be 11 digits long.";
    }
}

// Email validation
if (empty($email)) {
    $response['errors']['email'] = "Email cannot be empty.";
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $response['errors']['email'] = "Invalid email format.";
} elseif ($email != $row['Email'] && uniqueEmail($email) === false) {
    $response['errors']['email'] = "Email already exists.";
}

// Username validation
if (empty($username)) {
    $response['errors']['username'] = "Username cannot be empty.";
} elseif (!preg_match("/^[a-zA-Z-']*$/", $username)) {
    $response['errors']['username'] = "Username contains invalid characters.";
}

// If there are no errors, update user info
if (empty($response['errors'])) {
    if (updateUserInfo($id, $fullname, $email, $phone, $username) === true) {
        $response['success'] = true;
    } else {
        $response['errors']['general'] = "Failed to update user information.";
    }
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);

?>
