<?php
include('../model/user-info-model.php');

$password = $_POST['password'];
$id = $_COOKIE['id'];

if(correctPassword($id, $password)) echo 'true';
else echo 'false';
    
?>