<?php 

require_once('../model/user-info-model.php');

function sanitize($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

$fullname = sanitize($_POST['fullname']);
$email = sanitize($_POST['email']);
$phone = sanitize($_POST['phone']);
$username = sanitize($_POST['username']);
$password = sanitize($_POST['password']);
$cpassword = sanitize($_POST['cpassword']);
$gender = isset($_POST['gender']) ? sanitize($_POST['gender']) : ''; 
$role = "User";

if(empty($fullname) || empty($phone) || empty($email) || empty($username) || empty($password) || empty($cpassword) || empty($gender)) {
    header('location:../View/sign-up.php?err=empty'); 
    exit();
}

// Fullname validation
$namepart = explode(' ', $fullname);
if(count($namepart) < 2 || !preg_match("/^[a-zA-Z-' ]*$/",$fullname)) {
    header('location:../View/sign-up.php?err=fullnameInvalid'); 
    exit();
}

// Phone validation
if(!preg_match("/^01[0-9]{9}$/", $phone)) {
    header('location:../View/sign-up.php?err=phoneInvalid'); 
    exit();
}

// Email validation
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !uniqueEmail($email)) {
    header('location:../View/sign-up.php?err=emailInvalid'); 
    exit();
}

// Username validation
if (!preg_match("/^[a-zA-Z-']*$/", $username)){
    header('location:../View/sign-up.php?err=usernameInvalid'); 
    exit();
}

// Password validation
if (strlen($password) < 8 || $password != $cpassword) {
    header('location:../View/sign-up.php?err=passwordMismatch'); 
    exit();
}

// Call signup function
$status = signup($fullname, $phone, $email, $username, $password, $gender, $role);
if($status) {
    header('location:../view/sign-in.php?success=created');
} else {
    header('location:../View/sign-up.php?err=signupFailed'); 
}
?>
