<?php
// my_gallery.php

session_start();
require_once 'config.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$error = "";
$success = "";

// Check for success or error messages from gallery.php
if (isset($_GET['success'])) {
    $success = $_GET['success'];
} elseif (isset($_GET['error'])) {
    $error = $_GET['error'];
}

// Handle file deletion
if (isset($_GET['delete'])) {
    $photo_id = $_GET['delete'];
    $sql = "SELECT filename FROM photos WHERE id = ? AND user_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ii", $photo_id, $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
        $filename = $row['filename'];
        $sql = "DELETE FROM photos WHERE id = ? AND user_id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ii", $photo_id, $user_id);
        
        if (mysqli_stmt_execute($stmt)) {
            if (file_exists($filename)) {
                unlink($filename);
            }
            $success = "Photo deleted successfully.";
        } else {
            $error = "Error deleting photo.";
        }
    }
}

// Fetch user photos
$sql = "SELECT * FROM photos WHERE user_id = ? ORDER BY id DESC";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Photo Gallery</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>My Photo Gallery</h2>
        <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>
        <?php if (!empty($success)) echo "<p class='success'>$success</p>"; ?>
        
        <a href="gallery.php">Upload New Photo</a>

        <div class="gallery">
            <?php if (mysqli_num_rows($result) > 0) : ?>
                <?php while ($row = mysqli_fetch_assoc($result)) : ?>
                    <div class="photo">
                        <img src="<?= htmlspecialchars($row['filename']) ?>" alt="Photo">
                        <a href="my_gallery.php?delete=<?= $row['id'] ?>" onclick="return confirm('Are you sure you want to delete this photo?');">Remove</a>
                    </div>
                <?php endwhile; ?>
            <?php else : ?>
                <p>No photos uploaded.</p>
            <?php endif; ?>
        </div>

        <a href="logout.php">Logout</a>
    </div>
</body>
</html>